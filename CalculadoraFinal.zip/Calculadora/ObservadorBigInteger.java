import java.math.BigInteger;

public interface ObservadorBigInteger {
    void mudou(BigInteger valor);
}